//
//  ViewController.swift
//  Mapkit
//
//  Created by imac os on 12/29/19.
//  Copyright © 2019 imac os. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
class ViewController: UIViewController ,CLLocationManagerDelegate, MKMapViewDelegate{
    var latitudeForCurrentLocation : Double = 0.0
    var lognitudeForCurrentLocation: Double = 0.0
    var center = CLLocationCoordinate2D()
    var locManagerForCurrentLocation = CLLocationManager()
    var currentLocation: CLLocation!
    var points = [CLLocationCoordinate2D]()

    @IBOutlet var mapkit: MKMapView!
    override func viewDidLoad() {
        super.viewDidLoad()
        getCurrentLocation()
        mapkit.delegate = self
        
        mapkit.mapType = MKMapType.standard
        mapkit.isZoomEnabled = true
        mapkit.isScrollEnabled = true
        mapkit.showsUserLocation = true
        mapkit.center = view.center
        self.locManagerForCurrentLocation.delegate = self
        locManagerForCurrentLocation.desiredAccuracy = kCLLocationAccuracyBest
        locManagerForCurrentLocation.requestAlwaysAuthorization()
        if CLLocationManager.locationServicesEnabled() {
            locManagerForCurrentLocation.startUpdatingLocation()
        }
        
        
    }
    func getCurrentLocation ()  {
        if CLLocationManager.locationServicesEnabled(){
            guard let lat = locManagerForCurrentLocation.location?.coordinate.latitude else{
                return print("Fatal error, not getting locotion service")
            }
            let lng = locManagerForCurrentLocation.location?.coordinate.longitude
            latitudeForCurrentLocation = lat
           lognitudeForCurrentLocation = lng!
            print("latitude for current location is :\(latitudeForCurrentLocation) and longitude is :\(lognitudeForCurrentLocation)")
            
        }
        points.append(CLLocationCoordinate2DMake(latitudeForCurrentLocation, lognitudeForCurrentLocation))
        points.append(CLLocationCoordinate2DMake(23.5540244750357, 90.5664424959305))
        let polyline = MKPolyline(coordinates: &points, count: points.count)
        mapkit.addOverlay(polyline)
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        let userLocation:CLLocation = locations[0] as CLLocation
        let center = CLLocationCoordinate2D(latitude:userLocation.coordinate.latitude,longitude:userLocation.coordinate.longitude)
        let region = MKCoordinateRegion(center:center, span:MKCoordinateSpan(latitudeDelta:0.01,longitudeDelta:0.01))
        mapkit.setRegion(region,animated:true)
        let myAnnotation:MKPointAnnotation = MKPointAnnotation()
        myAnnotation.coordinate = CLLocationCoordinate2DMake(userLocation.coordinate.latitude,userLocation.coordinate.longitude);
        myAnnotation.title = "current location"
        myAnnotation.subtitle = "location subtitle"
        mapkit.addAnnotation(myAnnotation)
        let myAnnotation2:MKPointAnnotation = MKPointAnnotation()
        myAnnotation2.coordinate = CLLocationCoordinate2DMake(userLocation.coordinate.latitude,userLocation.coordinate.longitude);
        myAnnotation2.title = "current location"
        myAnnotation2.subtitle = "location subtitle"
        mapkit.addAnnotation(myAnnotation2)
        

    
    }
    func locationManager(_manager:CLLocationManager, didFailWithError error:Error){
        print("Error \(error)")
    }
    //////
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
     
        let renderer = MKPolylineRenderer(overlay: overlay)
        renderer.strokeColor = UIColor.red
        renderer.lineWidth = 4.0
        
        return renderer
    }
    ///
    func reverseGEOCODE(latidue: CLLocationDegrees, longitude: CLLocationDegrees) {
    let geoCoder = CLGeocoder()
    let location = CLLocation(latitude: latidue, longitude: longitude)
        geoCoder.reverseGeocodeLocation(location, completionHandler: { placemarks, Error in
            guard let addressDict = placemarks?[0].addressDictionary else{
                return
            }
            addressDict.forEach { _ in
                
            }
            if let formattedAddress = addressDict[" formattedAddress"] as? [String]{
                return
            }
            if let  locationName = addressDict["name"] as? String{
                print("location nmae = \(locationName)")
            }
            if let street = addressDict["Thoroughfare"] as? String{
                print("street = \(street)")
            }
            if let city = addressDict["City"] as? String {
                print("city = \(city)")
            }
            if let zip = addressDict["ZIP"] as? String{
                print("zip = \(zip)")
            }
            if let country = addressDict["Country"] as? String{
                print("country = \(country)")
            }
            
        }
        
        
        
        
        )
           
            
        
    }
}

